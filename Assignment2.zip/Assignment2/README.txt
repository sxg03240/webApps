This is poker game assignment-2 for web apps development

Using :

JS
JQuery
Bootstrap
HTML
CSS

